/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DatabaseWork;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Student;

/**
 *
 * @author Utpala khatri
 */
public class DatabaseOperation {
    public Student saveStudent(Student student) throws ClassNotFoundException, SQLException {
        Connection conn= DatabaseConnectivity.getDbConnect();
        String insert_query="insert into student_record(name,address,phoneNumber,gender,email,password)values(?,?,?,?,?,?)";
        PreparedStatement statement=conn.prepareStatement(insert_query);
         statement.setString(1, student.getName());
         statement.setString(2, student.getAddress());
         statement.setLong(3,student.getPhoneNumber());
         statement.setString(4,student.getGender());
         statement.setString(5,student.getEmail());
         statement.setString(6,student.getPassword());
         
         int row=statement.executeUpdate();
         if(row>0){
             return student;
         }
         else{
             return null;
         }
    }
}
